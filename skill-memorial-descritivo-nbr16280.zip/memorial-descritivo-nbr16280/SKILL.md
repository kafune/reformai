---
name: memorial-descritivo-nbr16280
description: Gera Memorial Descritivo de Reforma em Unidade Autônoma em DOCX conforme ABNT NBR 16.280:2024 (edição atualizada com Emenda 1 de 23.01.2024), no padrão visual Veríssimo Gestão Técnica Predial. Use esta skill SEMPRE que o usuário pedir para criar, gerar, montar, redigir ou preparar um memorial descritivo de reforma para unidade autônoma ou condomínio. Ative também quando mencionar "memorial descritivo", "memorial NBR 16280", "memorial de reforma", "memorial para o síndico", "memorial para aprovação de obra", "documento para ART de reforma", "comunicado de reforma ao condomínio", "plano de reforma em DOCX", "reforma em unidade autônoma", "memorial para emissão de ART", ou variações. A skill coleta os dados do cliente, classifica a obra conforme a Tabela A.1 da norma (empresa capacitada × empresa especializada) e gera um DOCX completo cobrindo TODOS os requisitos obrigatórios do §5.1 e §5.2 da NBR 16.280:2024.
license: Proprietary - Veríssimo Gestão Técnica Predial
---

# Memorial Descritivo de Reforma — NBR 16.280:2024

## Objetivo da skill

Gerar memorial descritivo profissional em DOCX para reformas em unidades autônomas em condomínio, no **padrão visual Veríssimo Gestão Técnica Predial** (navy `#0B1F3A` / gold `#C8A24B` / Georgia) e **conforme ABNT NBR 16.280:2024**, cobrindo todos os 14 requisitos obrigatórios do §5.1 e os requisitos do §5.2.

O memorial gerado é o documento técnico que instrui:
- A comunicação formal ao síndico / responsável legal (§6.2.1)
- A emissão da ART pelo responsável técnico
- O protocolo de aprovação da obra no condomínio

## ⚠️ Atualização importante da norma

A NBR 16.280 teve edições em 2014, 2015, 2020 e **2024**. A versão vigente é a **ABNT NBR 16.280:2024** (equivale à 2020 + Emenda 1 de 23.01.2024). **NUNCA cite "NBR 16.280:2015"** em novos memoriais — sempre **"ABNT NBR 16.280:2024"**.

## Workflow de uso

### Passo 1 — Coleta de dados

Pergunte ao usuário (de forma objetiva, em bloco único):

**Bloco 1 — Identificação da unidade**
1. Nome completo da proprietária / proprietário
2. CPF
3. Endereço completo da obra (rua, número, apartamento/sala)
4. Cidade / UF
5. Nome do condomínio (se houver, para citação formal)

**Bloco 2 — Escopo e prazos**
6. Escopo resumido da obra (ex.: troca de piso, pintura, ajustes elétricos superficiais)
7. Prazo estimado em dias úteis
8. Data prevista de início (opcional — se não informado, usar "a combinar com a administração")

**Bloco 3 — Empresa executora**
9. Nome da empresa que executará a obra (razão social)
10. CNPJ da empresa (se houver — caso seja autônomo, registrar "Profissional autônomo")
11. Telefone / e-mail para contato

Se o usuário já forneceu parte dos dados na mensagem original, não repita as perguntas — peça apenas o que falta.

### Passo 2 — Classificação da obra (Tabela A.1 / Anexo A)

Com base no escopo informado, classifique a obra em **empresa capacitada** OU **empresa especializada** conforme a Tabela A.1 da norma. Consulte o arquivo `tabela-a1-classificacao.md` para o critério exato.

Regra prática resumida:
- **Troca de revestimentos SEM martelete de alto impacto** → capacitada
- **Troca de revestimentos COM martelete de alto impacto** → especializada
- **Pintura, substituição de espelhos/interruptores sem alterar circuito** → capacitada
- **Qualquer intervenção em estrutura, impermeabilização, fachada, vedação (alteração), prumada** → especializada
- **Alteração do sistema elétrico / hidráulico / gás / ar-condicionado com demanda diferente da original** → especializada

Se houver dúvida, confirme com o usuário antes de gerar.

### Passo 3 — Geração do DOCX

Rode o script `gerar.js` passando os dados coletados como objeto JavaScript editado diretamente no topo do arquivo (seção DADOS). O script valida o DOCX ao final.

```bash
cd <diretorio-skill>
node gerar.js
python3 /mnt/skills/public/docx/scripts/office/validate.py <arquivo.docx>
cp <arquivo.docx> /mnt/user-data/outputs/
```

### Passo 4 — Entrega

Use `present_files` com o DOCX final. Mensagem curta explicando:
- Versão da norma (2024)
- Classificação aplicada (capacitada / especializada)
- Quaisquer seções condicionais incluídas/omitidas

## Estrutura obrigatória do documento

O memorial DEVE ter as seguintes seções — a ausência de qualquer uma é descumprimento do §5.1 ou §5.2 da NBR 16.280:2024.

| # | Seção | Norma de referência |
|---|-------|---------------------|
| - | Capa / bloco-título navy com selo "Conforme ABNT NBR 16.280:2024" | — |
| - | Ficha técnica (proprietário, unidade, RT, data) | — |
| 1 | Objetivo | §5.1 + §6.2.1 |
| 2 | Caracterização e classificação da reforma | §3.5 + Anexo A (Tabela A.1) |
| 3 | Escopo dos serviços | §5.1.e |
| 4 | Cronograma | §5.1.i |
| 5 | Dados das empresas e profissionais envolvidos | §5.1.j + §5.1.k |
| 6 | Atendimento à legislação e às normas técnicas | §5.1.a |
| 7 | Segurança da edificação e dos usuários | §5.1.b + §5.2.1 + §5.2.2 (NBR 9077) |
| 8 | Geração de ruído e níveis de pressão sonora | §5.1.f |
| 9 | Materiais tóxicos, combustíveis e inflamáveis | §5.1.g |
| 10 | Localização e implicações no entorno | §5.1.h |
| 11 | Procedimentos executivos | §5.1.b |
| 12 | Gestão de resíduos e armazenamento de insumos | §5.1.l + §5.1.m |
| 13 | Controle de terminalidade e alteração de escopo | §5.2.3 + §5.2.4 |
| 14 | Desempenho e continuidade da manutenção | §4.h + NBR 5674 + NBR 15575 |
| 15 | Atualização do manual de uso, operação e manutenção | **§5.1.n + NBR 14037 + NBR 17170** (obrigatório) |
| 16 | Termo de encerramento da obra | §6.1.3.a |
| 17 | Limitações da intervenção | — (boa prática) |
| 18 | Conclusão | — |
| - | Assinatura do responsável técnico | §5.1.k |

**Seções 8, 9, 15 e 16 são o que mais distingue o memorial conforme a NBR 2024 de um memorial genérico.** Não as omita.

## Padrão visual Veríssimo (IMUTÁVEL)

- **Cores**: navy `#0B1F3A` (títulos, selos), gold `#C8A24B` (réguas, destaques, CREA), texto `#1A1A1A`, muted `#6B6B6B` para elementos secundários, BG soft `#F5F1E8` para caixas de destaque.
- **Tipografia**: Georgia (corpo), Arial (fallback universal).
- **Papel**: A4, margens 1″ (top 1700 DXA para acomodar cabeçalho).
- **Cabeçalho de página**: logotipo "VERÍSSIMO · GESTÃO TÉCNICA PREDIAL" + título do documento à direita + régua dourada.
- **Rodapé de página**: CNPJ, endereço, site, paginação "Página X de Y".
- **Bullets**: marcador `▪` dourado.
- **Headings**: navy com régua dourada inferior.

**Nunca trocar Georgia por outra fonte. Nunca inverter navy/gold. Nunca usar outras cores sem motivo técnico.**

## Dados fixos da empresa (IMUTÁVEIS)

```
Razão social: VERÍSSIMO GESTÃO TÉCNICA PREDIAL LTDA
CNPJ: 60.353.313/0001-55
Endereço: Av. Salgado Filho, 2150 – Sala 303C – Guarulhos/SP
Site: verissimogtp.com.br

Responsável Técnico: Erisvaldo Veríssimo da Silva
Título: Engenheiro Civil
Registro: CREA-SP 5070239349
```

## Arquivos da skill

- `SKILL.md` — este arquivo
- `gerar.js` — template Node.js parametrizado que gera o DOCX completo
- `tabela-a1-classificacao.md` — referência da Tabela A.1 da norma para classificar a obra
- `checklist-nbr16280.md` — checklist de validação dos 14 requisitos do §5.1 e dos requisitos do §5.2

## Validação antes de entregar

Antes de chamar `present_files`:

1. Validar DOCX com o script padrão: `python3 /mnt/skills/public/docx/scripts/office/validate.py <arquivo>`
2. Converter para PDF e checar a primeira página: `soffice --convert-to pdf && pdftoppm -f 1 -l 1 ...`
3. Confirmar que o selo está "Conforme ABNT NBR 16.280:**2024**" (não 2015).
4. Conferir que as 18 seções estão presentes (ver `checklist-nbr16280.md`).

## Nome do arquivo de saída

Padrão: `Memorial_Descritivo_NBR16280_<identificador-curto-da-obra>.docx`

Exemplos:
- `Memorial_Descritivo_NBR16280_Apto1205_Avanhandava.docx`
- `Memorial_Descritivo_NBR16280_Sala_402_Paulista.docx`

Manter acentos fora do nome do arquivo.
