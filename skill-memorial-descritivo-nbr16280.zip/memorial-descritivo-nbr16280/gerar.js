// ============================================================================
// MEMORIAL DESCRITIVO DE REFORMA EM UNIDADE AUTÔNOMA
// Conforme ABNT NBR 16.280:2024 (Emenda 1 de 23.01.2024)
// Padrão visual: Veríssimo Gestão Técnica Predial
// ============================================================================
// Uso:
//   1. Edite o bloco DADOS abaixo com as informações da obra
//   2. Edite o array ESCOPO_SERVICOS com os serviços da obra específica
//   3. Execute:  node gerar.js
//   4. Valide:   python3 /mnt/skills/public/docx/scripts/office/validate.py <arquivo>
//   5. Copie:    cp <arquivo> /mnt/user-data/outputs/
// ============================================================================

const fs = require('fs');
const {
  Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell,
  Header, Footer, AlignmentType, LevelFormat, HeadingLevel, BorderStyle,
  WidthType, ShadingType, VerticalAlign, PageNumber, TabStopType,
  TabStopPosition,
} = require('docx');

// ============================================================================
// DADOS DA OBRA — EDITAR AQUI
// ============================================================================
const DADOS = {
  // Bloco 1 — Identificação
  proprietaria: "Milene Santos de Matos",
  cpf: "276.270.648-30",
  endereco: "Rua Avanhandava, nº 459 – Apartamento 1205",
  cidade: "São Paulo/SP",
  condominio: null, // ex.: "Condomínio Edifício Avanhandava" ou null

  // Bloco 2 — Escopo e prazos
  prazo_dias_uteis: 20,
  horario_obra: "das 08h às 17h, de segunda a sexta-feira, e aos sábados das 09h às 13h, respeitado o regulamento interno do condomínio",

  // Bloco 3 — Empresa executora (se não informado, usar "A ser contratada pela proprietária")
  executora_nome: "A ser contratada pela proprietária",
  executora_cnpj: "",
  executora_contato: "",

  // Bloco 4 — Classificação conforme Tabela A.1 (NBR 16.280:2024)
  // Valores: "capacitada" | "especializada"
  classificacao_responsavel: "capacitada",
  classificacao_justificativa:
    "a obra contempla troca de revestimento sem uso de martelete ou ferramentas de alto impacto, " +
    "pintura interna, e substituição de dispositivos elétricos (espelhos, interruptores e tomadas) " +
    "sem alteração de circuitos ou de carga instalada — hipóteses expressamente enquadradas na " +
    "Tabela A.1 da NBR 16.280:2024 como executáveis por empresa capacitada",

  // Nome do arquivo de saída
  nome_arquivo: "Memorial_Descritivo_NBR16280_Apto1205_Avanhandava.docx",
};

// ============================================================================
// ESCOPO DOS SERVIÇOS — EDITAR conforme obra específica
// ============================================================================
const ESCOPO_SERVICOS = [
  {
    titulo: "3.1 Remoção de revestimento existente",
    itens: [
      "Demolição dos pisos existentes nas áreas internas da unidade, realizada por método manual, sem uso de ferramentas de alto impacto (marteletes, rompedores ou similares).",
      "Remoção da argamassa de assentamento aderida ao contrapiso.",
      "Destinação adequada dos resíduos gerados, conforme detalhado na Seção 12 deste memorial.",
    ],
  },
  {
    titulo: "3.2 Execução de novo revestimento de piso",
    itens: [
      "Regularização pontual do contrapiso, quando necessária.",
      "Assentamento de novo revestimento cerâmico ou similar, conforme especificação da proprietária.",
      "Execução de rejuntamento, observando as orientações técnicas do fabricante.",
      "Limpeza final, acabamento e conferência das áreas executadas.",
    ],
  },
  {
    titulo: "3.3 Pintura interna",
    itens: [
      "Preparação das superfícies: limpeza, lixamento e correção de pequenas imperfeições.",
      "Aplicação de selador acrílico ou fundo preparador de parede, quando necessário.",
      "Aplicação de tinta em paredes e/ou tetos internos da unidade, em demãos suficientes para cobertura uniforme.",
    ],
  },
  {
    titulo: "3.4 Intervenções elétricas superficiais",
    itens: [
      "Substituição de espelhos de tomadas e interruptores, mantidas as características originais dos pontos.",
      "Ajustes pontuais sem alteração de circuitos, de bitola de condutores ou da carga instalada no quadro de distribuição da unidade.",
    ],
  },
];

// ============================================================================
// LIMITAÇÕES DA INTERVENÇÃO — ajustar conforme obra
// ============================================================================
const LIMITACOES = [
  "Intervenções em elementos estruturais, tais como lajes, vigas, pilares e elementos de contraventamento.",
  "Alterações em prumadas hidráulicas, de esgoto, de gás, de incêndio ou em circuitos elétricos coletivos.",
  "Modificações em fachada, esquadrias externas, guarda-corpos, marquises ou demais áreas comuns.",
  "Alterações de layout que impliquem demolição ou deslocamento de paredes estruturais ou de vedação com função de compartimentação.",
  "Intervenções em sistemas de impermeabilização existentes.",
];

// ============================================================================
// DADOS FIXOS DA EMPRESA (NÃO EDITAR)
// ============================================================================
const EMPRESA = {
  razao: "VERÍSSIMO GESTÃO TÉCNICA PREDIAL LTDA",
  cnpj: "60.353.313/0001-55",
  endereco: "Av. Salgado Filho, 2150 – Sala 303C – Guarulhos/SP",
  site: "verissimogtp.com.br",
};

const RESPONSAVEL = {
  nome: "Erisvaldo Veríssimo da Silva",
  titulo: "Engenheiro Civil",
  crea: "CREA-SP 5070239349",
};

const HOJE = new Date().toLocaleDateString('pt-BR', {
  day: '2-digit', month: 'long', year: 'numeric',
});

// ============================================================================
// PALETA VERÍSSIMO (NÃO EDITAR)
// ============================================================================
const NAVY = "0B1F3A";
const GOLD = "C8A24B";
const DARK_TEXT = "1A1A1A";
const LIGHT_GREY = "E8E8E8";
const MUTED = "6B6B6B";
const BG_SOFT = "F5F1E8";

// ============================================================================
// HELPERS
// ============================================================================
const border = { style: BorderStyle.SINGLE, size: 4, color: LIGHT_GREY };
const borderAll = { top: border, bottom: border, left: border, right: border };
const borderNone = {
  top: { style: BorderStyle.NONE, size: 0, color: "FFFFFF" },
  bottom: { style: BorderStyle.NONE, size: 0, color: "FFFFFF" },
  left: { style: BorderStyle.NONE, size: 0, color: "FFFFFF" },
  right: { style: BorderStyle.NONE, size: 0, color: "FFFFFF" },
};

function p(text, opts = {}) {
  return new Paragraph({
    spacing: { before: opts.before ?? 0, after: opts.after ?? 120, line: 300 },
    alignment: opts.align ?? AlignmentType.JUSTIFIED,
    indent: opts.indent,
    children: [
      new TextRun({
        text,
        font: opts.font ?? "Georgia",
        size: opts.size ?? 22,
        bold: opts.bold ?? false,
        italics: opts.italics ?? false,
        color: opts.color ?? DARK_TEXT,
      }),
    ],
  });
}

function h1(text) {
  return new Paragraph({
    spacing: { before: 360, after: 160 },
    heading: HeadingLevel.HEADING_1,
    children: [
      new TextRun({
        text: text.toUpperCase(),
        font: "Georgia", size: 26, bold: true, color: NAVY,
      }),
    ],
    border: {
      bottom: { style: BorderStyle.SINGLE, size: 12, color: GOLD, space: 6 },
    },
  });
}

function subh(text) {
  return new Paragraph({
    spacing: { before: 200, after: 100 },
    children: [
      new TextRun({
        text, font: "Georgia", size: 23, bold: true, color: NAVY,
      }),
    ],
  });
}

function bullet(text) {
  return new Paragraph({
    spacing: { before: 40, after: 80, line: 290 },
    alignment: AlignmentType.JUSTIFIED,
    numbering: { reference: "bullets", level: 0 },
    children: [
      new TextRun({ text, font: "Georgia", size: 22, color: DARK_TEXT }),
    ],
  });
}

// ============================================================================
// CABEÇALHO DE PÁGINA
// ============================================================================
const header = new Header({
  children: [
    new Table({
      width: { size: 9360, type: WidthType.DXA },
      columnWidths: [5600, 3760],
      borders: {
        top: { style: BorderStyle.NONE, size: 0, color: "FFFFFF" },
        bottom: { style: BorderStyle.NONE, size: 0, color: "FFFFFF" },
        left: { style: BorderStyle.NONE, size: 0, color: "FFFFFF" },
        right: { style: BorderStyle.NONE, size: 0, color: "FFFFFF" },
        insideHorizontal: { style: BorderStyle.NONE, size: 0, color: "FFFFFF" },
        insideVertical: { style: BorderStyle.NONE, size: 0, color: "FFFFFF" },
      },
      rows: [
        new TableRow({
          children: [
            new TableCell({
              borders: borderNone,
              width: { size: 5600, type: WidthType.DXA },
              verticalAlign: VerticalAlign.CENTER,
              margins: { top: 40, bottom: 40, left: 0, right: 0 },
              children: [
                new Paragraph({
                  spacing: { after: 0 },
                  children: [
                    new TextRun({ text: "VERÍSSIMO", font: "Georgia", size: 24, bold: true, color: NAVY }),
                    new TextRun({ text: "  GESTÃO TÉCNICA PREDIAL", font: "Georgia", size: 16, color: GOLD, bold: true }),
                  ],
                }),
                new Paragraph({
                  spacing: { before: 20, after: 0 },
                  children: [
                    new TextRun({ text: "Engenharia Consultiva · Vistorias · NBR 16.280", font: "Georgia", size: 15, italics: true, color: MUTED }),
                  ],
                }),
              ],
            }),
            new TableCell({
              borders: borderNone,
              width: { size: 3760, type: WidthType.DXA },
              verticalAlign: VerticalAlign.CENTER,
              margins: { top: 40, bottom: 40, left: 0, right: 0 },
              children: [
                new Paragraph({
                  alignment: AlignmentType.RIGHT,
                  spacing: { after: 0 },
                  children: [
                    new TextRun({ text: "Memorial Descritivo", font: "Georgia", size: 16, bold: true, color: NAVY }),
                  ],
                }),
                new Paragraph({
                  alignment: AlignmentType.RIGHT,
                  spacing: { before: 20, after: 0 },
                  children: [
                    new TextRun({ text: "ABNT NBR 16.280:2024", font: "Georgia", size: 14, color: MUTED, italics: true }),
                  ],
                }),
              ],
            }),
          ],
        }),
      ],
    }),
    new Paragraph({
      spacing: { before: 0, after: 0 },
      border: { bottom: { style: BorderStyle.SINGLE, size: 12, color: GOLD, space: 4 } },
      children: [new TextRun({ text: "" })],
    }),
  ],
});

// ============================================================================
// RODAPÉ DE PÁGINA
// ============================================================================
const footer = new Footer({
  children: [
    new Paragraph({
      spacing: { before: 0, after: 0 },
      border: { top: { style: BorderStyle.SINGLE, size: 6, color: NAVY, space: 4 } },
      children: [new TextRun({ text: "" })],
    }),
    new Paragraph({
      alignment: AlignmentType.CENTER,
      spacing: { before: 60, after: 0 },
      children: [
        new TextRun({ text: `${EMPRESA.razao}  ·  CNPJ ${EMPRESA.cnpj}`, font: "Georgia", size: 14, color: NAVY, bold: true }),
      ],
    }),
    new Paragraph({
      alignment: AlignmentType.CENTER,
      spacing: { before: 20, after: 0 },
      children: [
        new TextRun({ text: `${EMPRESA.endereco}  ·  ${EMPRESA.site}`, font: "Georgia", size: 13, color: MUTED }),
      ],
    }),
    new Paragraph({
      alignment: AlignmentType.RIGHT,
      spacing: { before: 40, after: 0 },
      children: [
        new TextRun({ text: "Página ", font: "Georgia", size: 13, color: MUTED }),
        new TextRun({ children: [PageNumber.CURRENT], font: "Georgia", size: 13, color: NAVY, bold: true }),
        new TextRun({ text: " de ", font: "Georgia", size: 13, color: MUTED }),
        new TextRun({ children: [PageNumber.TOTAL_PAGES], font: "Georgia", size: 13, color: NAVY, bold: true }),
      ],
    }),
  ],
});

// ============================================================================
// BLOCO-TÍTULO (CAPA)
// ============================================================================
const blocoTitulo = new Table({
  width: { size: 9360, type: WidthType.DXA },
  columnWidths: [9360],
  borders: {
    top: { style: BorderStyle.SINGLE, size: 18, color: GOLD },
    bottom: { style: BorderStyle.SINGLE, size: 18, color: GOLD },
    left: { style: BorderStyle.SINGLE, size: 4, color: GOLD },
    right: { style: BorderStyle.SINGLE, size: 4, color: GOLD },
    insideHorizontal: { style: BorderStyle.NONE, size: 0, color: "FFFFFF" },
    insideVertical: { style: BorderStyle.NONE, size: 0, color: "FFFFFF" },
  },
  rows: [
    new TableRow({
      children: [
        new TableCell({
          borders: { top: { style: BorderStyle.NONE }, bottom: { style: BorderStyle.NONE }, left: { style: BorderStyle.NONE }, right: { style: BorderStyle.NONE } },
          width: { size: 9360, type: WidthType.DXA },
          shading: { fill: NAVY, type: ShadingType.CLEAR },
          margins: { top: 360, bottom: 360, left: 400, right: 400 },
          children: [
            new Paragraph({
              alignment: AlignmentType.CENTER,
              spacing: { after: 80 },
              children: [new TextRun({ text: "MEMORIAL DESCRITIVO", font: "Georgia", size: 40, bold: true, color: "FFFFFF" })],
            }),
            new Paragraph({
              alignment: AlignmentType.CENTER,
              spacing: { after: 120 },
              children: [new TextRun({ text: "DE REFORMA EM UNIDADE AUTÔNOMA", font: "Georgia", size: 22, color: GOLD, bold: true })],
            }),
            new Paragraph({
              alignment: AlignmentType.CENTER,
              spacing: { after: 0 },
              children: [new TextRun({ text: "Conforme ABNT NBR 16.280:2024", font: "Georgia", size: 18, italics: true, color: "E8E8E8" })],
            }),
          ],
        }),
      ],
    }),
  ],
});

// ============================================================================
// FICHA TÉCNICA
// ============================================================================
function fichaRow(label, value) {
  return new TableRow({
    children: [
      new TableCell({
        borders: borderAll,
        width: { size: 2800, type: WidthType.DXA },
        shading: { fill: BG_SOFT, type: ShadingType.CLEAR },
        margins: { top: 120, bottom: 120, left: 180, right: 120 },
        children: [new Paragraph({ children: [new TextRun({ text: label.toUpperCase(), font: "Georgia", size: 16, bold: true, color: NAVY })] })],
      }),
      new TableCell({
        borders: borderAll,
        width: { size: 6560, type: WidthType.DXA },
        margins: { top: 120, bottom: 120, left: 180, right: 120 },
        children: [new Paragraph({ children: [new TextRun({ text: value, font: "Georgia", size: 20, color: DARK_TEXT })] })],
      }),
    ],
  });
}

const fichaRows = [
  fichaRow("Proprietária", DADOS.proprietaria),
  fichaRow("CPF", DADOS.cpf),
  fichaRow("Endereço da Obra", DADOS.endereco),
  fichaRow("Cidade / UF", DADOS.cidade),
];
if (DADOS.condominio) fichaRows.push(fichaRow("Condomínio", DADOS.condominio));
fichaRows.push(
  fichaRow("Responsável Técnico", `${RESPONSAVEL.nome} — ${RESPONSAVEL.titulo}`),
  fichaRow("Registro Profissional", RESPONSAVEL.crea),
  fichaRow("Norma de Referência", "ABNT NBR 16.280:2024"),
  fichaRow("Data de Emissão", HOJE),
);

const fichaTecnica = new Table({
  width: { size: 9360, type: WidthType.DXA },
  columnWidths: [2800, 6560],
  rows: fichaRows,
});

// ============================================================================
// CAIXA DE CLASSIFICAÇÃO
// ============================================================================
const classifTexto = DADOS.classificacao_responsavel === "especializada"
  ? "empresa especializada"
  : "empresa capacitada";

const caixaClassificacao = new Table({
  width: { size: 9360, type: WidthType.DXA },
  columnWidths: [9360],
  borders: {
    top: { style: BorderStyle.SINGLE, size: 4, color: GOLD },
    bottom: { style: BorderStyle.SINGLE, size: 4, color: GOLD },
    left: { style: BorderStyle.SINGLE, size: 24, color: GOLD },
    right: { style: BorderStyle.SINGLE, size: 4, color: GOLD },
  },
  rows: [
    new TableRow({
      children: [
        new TableCell({
          borders: {
            top: { style: BorderStyle.SINGLE, size: 4, color: GOLD },
            bottom: { style: BorderStyle.SINGLE, size: 4, color: GOLD },
            left: { style: BorderStyle.SINGLE, size: 24, color: GOLD },
            right: { style: BorderStyle.SINGLE, size: 4, color: GOLD },
          },
          width: { size: 9360, type: WidthType.DXA },
          shading: { fill: BG_SOFT, type: ShadingType.CLEAR },
          margins: { top: 200, bottom: 200, left: 280, right: 220 },
          children: [
            new Paragraph({
              spacing: { after: 80 },
              children: [new TextRun({ text: "CLASSIFICAÇÃO DA REFORMA", font: "Georgia", size: 17, bold: true, color: NAVY })],
            }),
            new Paragraph({
              alignment: AlignmentType.JUSTIFIED,
              spacing: { line: 300 },
              children: [
                new TextRun({ text: "Intervenção de ", font: "Georgia", size: 22, color: DARK_TEXT }),
                new TextRun({ text: "baixo impacto estrutural", font: "Georgia", size: 22, bold: true, color: NAVY }),
                new TextRun({ text: ", limitada a acabamentos e instalações superficiais, ", font: "Georgia", size: 22, color: DARK_TEXT }),
                new TextRun({ text: "sem alteração", font: "Georgia", size: 22, bold: true, color: DARK_TEXT }),
                new TextRun({ text: " do layout estrutural da edificação, de prumadas ou de sistemas coletivos. ", font: "Georgia", size: 22, color: DARK_TEXT }),
                new TextRun({ text: `Conforme Anexo A (Tabela A.1) da norma, classifica-se como atividade executável por `, font: "Georgia", size: 22, color: DARK_TEXT }),
                new TextRun({ text: classifTexto, font: "Georgia", size: 22, bold: true, color: NAVY }),
                new TextRun({ text: `, considerando que ${DADOS.classificacao_justificativa}.`, font: "Georgia", size: 22, color: DARK_TEXT }),
              ],
            }),
          ],
        }),
      ],
    }),
  ],
});

// ============================================================================
// TABELA DE CRONOGRAMA SIMPLIFICADO
// ============================================================================
function cronRow(cells, isHeader = false) {
  return new TableRow({
    children: cells.map((c) => new TableCell({
      borders: borderAll,
      width: { size: c.w, type: WidthType.DXA },
      shading: isHeader ? { fill: NAVY, type: ShadingType.CLEAR } : undefined,
      margins: { top: 100, bottom: 100, left: 140, right: 100 },
      children: [new Paragraph({
        alignment: c.align ?? AlignmentType.LEFT,
        children: [new TextRun({ text: c.t, font: "Georgia", size: 19, bold: isHeader, color: isHeader ? "FFFFFF" : DARK_TEXT })],
      })],
    })),
  });
}

const cronograma = new Table({
  width: { size: 9360, type: WidthType.DXA },
  columnWidths: [800, 4560, 2000, 2000],
  rows: [
    cronRow([
      { t: "Etapa", w: 800, align: AlignmentType.CENTER },
      { t: "Atividade", w: 4560 },
      { t: "Duração (dias úteis)", w: 2000, align: AlignmentType.CENTER },
      { t: "Sequência", w: 2000, align: AlignmentType.CENTER },
    ], true),
    cronRow([
      { t: "1", w: 800, align: AlignmentType.CENTER },
      { t: "Mobilização, proteção de áreas comuns e preparação", w: 4560 },
      { t: "1", w: 2000, align: AlignmentType.CENTER },
      { t: "Dia 1", w: 2000, align: AlignmentType.CENTER },
    ]),
    cronRow([
      { t: "2", w: 800, align: AlignmentType.CENTER },
      { t: "Remoção de revestimento existente e retirada de entulho", w: 4560 },
      { t: `${Math.max(2, Math.round(DADOS.prazo_dias_uteis * 0.25))}`, w: 2000, align: AlignmentType.CENTER },
      { t: "Após etapa 1", w: 2000, align: AlignmentType.CENTER },
    ]),
    cronRow([
      { t: "3", w: 800, align: AlignmentType.CENTER },
      { t: "Regularização de contrapiso e assentamento de novo revestimento", w: 4560 },
      { t: `${Math.max(3, Math.round(DADOS.prazo_dias_uteis * 0.35))}`, w: 2000, align: AlignmentType.CENTER },
      { t: "Após etapa 2", w: 2000, align: AlignmentType.CENTER },
    ]),
    cronRow([
      { t: "4", w: 800, align: AlignmentType.CENTER },
      { t: "Pintura interna (paredes e tetos)", w: 4560 },
      { t: `${Math.max(2, Math.round(DADOS.prazo_dias_uteis * 0.20))}`, w: 2000, align: AlignmentType.CENTER },
      { t: "Após etapa 3", w: 2000, align: AlignmentType.CENTER },
    ]),
    cronRow([
      { t: "5", w: 800, align: AlignmentType.CENTER },
      { t: "Intervenções elétricas superficiais e acabamentos finais", w: 4560 },
      { t: `${Math.max(1, Math.round(DADOS.prazo_dias_uteis * 0.10))}`, w: 2000, align: AlignmentType.CENTER },
      { t: "Paralela à etapa 4", w: 2000, align: AlignmentType.CENTER },
    ]),
    cronRow([
      { t: "6", w: 800, align: AlignmentType.CENTER },
      { t: "Limpeza final, desmobilização e vistoria de encerramento", w: 4560 },
      { t: "1", w: 2000, align: AlignmentType.CENTER },
      { t: "Dia final", w: 2000, align: AlignmentType.CENTER },
    ]),
    cronRow([
      { t: "—", w: 800, align: AlignmentType.CENTER },
      { t: "PRAZO TOTAL ESTIMADO", w: 4560 },
      { t: `${DADOS.prazo_dias_uteis}`, w: 2000, align: AlignmentType.CENTER },
      { t: "—", w: 2000, align: AlignmentType.CENTER },
    ]),
  ],
});

// ============================================================================
// BLOCO DE ASSINATURA
// ============================================================================
const blocoAssinatura = new Table({
  width: { size: 9360, type: WidthType.DXA },
  columnWidths: [9360],
  borders: borderNone,
  rows: [
    new TableRow({
      children: [
        new TableCell({
          borders: borderNone,
          width: { size: 9360, type: WidthType.DXA },
          margins: { top: 200, bottom: 0, left: 0, right: 0 },
          children: [
            new Paragraph({
              alignment: AlignmentType.CENTER,
              spacing: { after: 120 },
              children: [new TextRun({ text: `Guarulhos/SP, ${HOJE}.`, font: "Georgia", size: 22, color: DARK_TEXT })],
            }),
            new Paragraph({
              alignment: AlignmentType.CENTER,
              spacing: { before: 600, after: 0 },
              border: { bottom: { style: BorderStyle.SINGLE, size: 8, color: NAVY, space: 1 } },
              children: [new TextRun({ text: "" })],
            }),
            new Paragraph({
              alignment: AlignmentType.CENTER,
              spacing: { before: 80, after: 0 },
              children: [new TextRun({ text: RESPONSAVEL.nome, font: "Georgia", size: 22, bold: true, color: NAVY })],
            }),
            new Paragraph({
              alignment: AlignmentType.CENTER,
              spacing: { before: 40, after: 0 },
              children: [new TextRun({ text: RESPONSAVEL.titulo, font: "Georgia", size: 20, color: DARK_TEXT })],
            }),
            new Paragraph({
              alignment: AlignmentType.CENTER,
              spacing: { before: 20, after: 0 },
              children: [new TextRun({ text: RESPONSAVEL.crea, font: "Georgia", size: 19, italics: true, color: GOLD, bold: true })],
            }),
            new Paragraph({
              alignment: AlignmentType.CENTER,
              spacing: { before: 20, after: 0 },
              children: [new TextRun({ text: "Responsável Técnico", font: "Georgia", size: 17, italics: true, color: MUTED })],
            }),
          ],
        }),
      ],
    }),
  ],
});

// ============================================================================
// MONTAGEM DO CONTEÚDO — 18 SEÇÕES + CAPA + ASSINATURA
// ============================================================================
const escopoConteudo = [];
for (const grupo of ESCOPO_SERVICOS) {
  escopoConteudo.push(subh(grupo.titulo));
  for (const item of grupo.itens) escopoConteudo.push(bullet(item));
}

const conteudo = [
  blocoTitulo,
  new Paragraph({ spacing: { after: 320 }, children: [new TextRun({ text: "" })] }),
  fichaTecnica,
  new Paragraph({ spacing: { after: 240 }, children: [new TextRun({ text: "" })] }),

  // ========== 1. OBJETIVO ==========
  h1("1. Objetivo"),
  p("O presente memorial descritivo tem por finalidade descrever, de forma clara e objetiva, os serviços a serem executados na unidade autônoma acima identificada, para fins de emissão da Anotação de Responsabilidade Técnica (ART) e de atendimento integral aos requisitos da ABNT NBR 16.280:2024 — Reforma em edificações — Sistema de gestão de reformas — Requisitos."),
  p("Este documento constitui, nos termos do item 6.2.1 da norma, a comunicação formal do proprietário ao responsável legal da edificação (síndico / administração do condomínio), e deve ser encaminhado antes do início da obra, acompanhado dos demais documentos exigidos pelo regimento interno condominial."),

  // ========== 2. CARACTERIZAÇÃO ==========
  h1("2. Caracterização e Classificação da Reforma"),
  p("A intervenção pretendida caracteriza-se, nos termos do item 3.5 da ABNT NBR 16.280:2024, como reforma de edificação — alteração nas condições da unidade existente, visando melhorar suas condições de habitabilidade e uso, sem configurar manutenção. Trata-se de serviços de acabamento e adequação interna, restritos ao interior da unidade, sem interferência em elementos estruturais, instalações coletivas ou áreas comuns do condomínio."),
  new Paragraph({ spacing: { after: 100 }, children: [new TextRun({ text: "" })] }),
  caixaClassificacao,
  new Paragraph({ spacing: { after: 0 }, children: [new TextRun({ text: "" })] }),

  // ========== 3. ESCOPO ==========
  h1("3. Escopo dos Serviços"),
  p("Nos termos do item 5.1, alínea “e”, da NBR 16.280:2024, descrevem-se a seguir os serviços que compõem o escopo da reforma:"),
  ...escopoConteudo,

  // ========== 4. CRONOGRAMA ==========
  h1("4. Cronograma da Reforma"),
  p("Em atendimento ao item 5.1, alínea “i”, da NBR 16.280:2024, apresenta-se o cronograma estimado da obra. As durações são expressas em dias úteis e poderão sofrer pequenos ajustes em função de variáveis operacionais, sem comprometer o prazo total previsto."),
  new Paragraph({ spacing: { after: 80 }, children: [new TextRun({ text: "" })] }),
  cronograma,
  new Paragraph({ spacing: { after: 80 }, children: [new TextRun({ text: "" })] }),
  p(`Horário de execução: ${DADOS.horario_obra}.`),

  // ========== 5. DADOS DAS EMPRESAS ==========
  h1("5. Empresas, Profissionais e Responsabilidades"),
  p("Nos termos dos itens 5.1, alíneas “j” e “k”, da NBR 16.280:2024, identificam-se abaixo os intervenientes técnicos da reforma, observadas as competências regulamentares das profissões envolvidas."),
  subh("5.1 Responsabilidade técnica"),
  bullet(`${RESPONSAVEL.nome} — ${RESPONSAVEL.titulo}, ${RESPONSAVEL.crea}, responsável técnico pelo projeto, pelo memorial e pela supervisão da obra, emitindo a respectiva Anotação de Responsabilidade Técnica (ART) junto ao CREA-SP.`),
  bullet(`${EMPRESA.razao}, CNPJ ${EMPRESA.cnpj}, ${EMPRESA.endereco}.`),
  subh("5.2 Empresa executora"),
  bullet(`Nome: ${DADOS.executora_nome}.`),
  ...(DADOS.executora_cnpj ? [bullet(`CNPJ: ${DADOS.executora_cnpj}.`)] : []),
  ...(DADOS.executora_contato ? [bullet(`Contato: ${DADOS.executora_contato}.`)] : []),
  bullet("A empresa executora deverá apresentar, antes do início dos serviços, a relação nominal dos funcionários que acessarão as dependências do condomínio, com cópia de documento de identificação, conforme exigência usual das administrações condominiais."),

  // ========== 6. LEGISLAÇÃO E NORMAS ==========
  h1("6. Atendimento à Legislação e às Normas Técnicas"),
  p("Em atendimento ao item 5.1, alínea “a”, da NBR 16.280:2024, a obra observará integralmente:"),
  bullet("ABNT NBR 16.280:2024 — Reforma em edificações — Sistema de gestão de reformas — Requisitos."),
  bullet("ABNT NBR 5674 — Manutenção de edificações — Requisitos para o sistema de gestão de manutenção."),
  bullet("ABNT NBR 9077 — Saídas de emergência em edificações."),
  bullet("ABNT NBR 14037 — Diretrizes para elaboração de manuais de uso, operação e manutenção das edificações."),
  bullet("ABNT NBR 15575 (todas as partes) — Edificações habitacionais — Desempenho."),
  bullet("ABNT NBR 17170 — Edificações — Garantias — Prazos recomendados e diretrizes."),
  bullet("Normas regulamentadoras do Ministério do Trabalho aplicáveis: NR-06 (EPI), NR-18 (Construção) e, quando pertinente, NR-35 (trabalho em altura)."),
  bullet("Resolução CONAMA nº 307/2002 e alterações, quanto à gestão dos resíduos da construção civil."),
  bullet("Regulamento interno e Convenção do condomínio, no que couber."),

  // ========== 7. SEGURANÇA ==========
  h1("7. Segurança da Edificação e dos Usuários"),
  p("Em atendimento aos itens 5.1 (alínea “b”), 5.2.1 e 5.2.2 da NBR 16.280:2024, a obra preservará a segurança da edificação, dos seus usuários e do entorno, observando-se as seguintes diretrizes de cumprimento obrigatório:"),
  bullet("Durante toda a execução, todos os sistemas de segurança existentes na edificação permanecerão em pleno funcionamento. Não haverá desativação, ainda que temporária, de detectores, sprinklers, sinalização, iluminação de emergência, hidrantes, extintores, portas corta-fogo ou qualquer outro sistema de proteção — item 5.2.1 da norma."),
  bullet("Em hipótese alguma haverá obstrução, mesmo temporária ou parcial, das saídas de emergência da edificação, conforme exigência expressa do item 5.2.2 da norma e em conformidade com a ABNT NBR 9077."),
  bullet("Rotas de fuga, elevadores de serviço, halls e demais áreas comuns de circulação permanecerão livres e devidamente sinalizadas durante todo o período da obra."),
  bullet("Os trabalhadores utilizarão os equipamentos de proteção individual (EPIs) e coletiva (EPCs) exigidos pelas NR-06, NR-18 e, quando aplicável, NR-35."),

  // ========== 8. RUÍDO ==========
  h1("8. Geração de Ruído e Níveis de Pressão Sonora"),
  p("Em atendimento ao item 5.1, alínea “f”, da NBR 16.280:2024, identificam-se a seguir as atividades da obra com potencial de geração de ruído e a previsão dos respectivos níveis de pressão sonora, a título orientativo:"),
  bullet("Remoção manual de revestimento cerâmico (ponteiro e marreta leve): níveis previstos entre 75 e 90 dB(A), medidos a 1 metro da fonte."),
  bullet("Lixamento de superfícies para pintura: níveis previstos entre 70 e 80 dB(A)."),
  bullet("Furadeira para fixações pontuais (se aplicável): níveis previstos entre 85 e 95 dB(A), em curtos períodos."),
  bullet("Atividades de acabamento (rejuntamento, aplicação de tinta, limpeza): níveis abaixo de 65 dB(A)."),
  p("Todas as atividades ruidosas serão restritas à janela de horário autorizada pelo regulamento interno do condomínio. Quando houver previsão de picos sonoros, os demais condôminos serão previamente comunicados por meio da administração, sempre que possível com antecedência mínima de 24 horas."),

  // ========== 9. MATERIAIS TÓXICOS, COMBUSTÍVEIS E INFLAMÁVEIS ==========
  h1("9. Materiais Tóxicos, Combustíveis e Inflamáveis"),
  p("Em atendimento ao item 5.1, alínea “g”, da NBR 16.280:2024, informa-se sobre o emprego de materiais com características tóxicas, combustíveis ou inflamáveis:"),
  bullet("Tintas, seladores acrílicos e complementos à base de água: produtos de baixa toxicidade. O ambiente será mantido ventilado durante e após a aplicação."),
  bullet("Argamassas e rejuntes: materiais de baixa toxicidade em uso. Os trabalhadores utilizarão máscaras PFF-2 durante a mistura de produtos em pó para evitar inalação."),
  bullet("Solventes, thinner e materiais inflamáveis: NÃO serão empregados em volume significativo. Se necessários em pequena quantidade para limpeza pontual de ferramentas, serão armazenados exclusivamente dentro da unidade, em recipientes fechados, afastados de fontes de calor, e em volume total inferior a 5 litros, atendendo às restrições de segurança do condomínio."),
  bullet("Fichas de Informação de Segurança de Produtos Químicos (FISPQ) dos materiais empregados serão mantidas pela empresa executora à disposição para consulta, nos termos da legislação trabalhista."),

  // ========== 10. ENTORNO ==========
  h1("10. Localização e Implicações no Entorno"),
  p("Em atendimento ao item 5.1, alínea “h”, da NBR 16.280:2024, registra-se que:"),
  bullet(`A unidade encontra-se situada em ${DADOS.endereco}, ${DADOS.cidade}, em edificação vertical de uso residencial/misto.`),
  bullet("A obra restringe-se ao interior da unidade autônoma, sem intervenção em áreas comuns, fachadas, lajes de cobertura ou elementos externos visíveis do logradouro público."),
  bullet("Não há interferência prevista em vias públicas, calçadas ou logradouros lindeiros à edificação. O acesso de materiais e a retirada de resíduos ocorrerão exclusivamente pelos acessos de serviço do condomínio, nos horários autorizados."),
  bullet("Os impactos sobre as unidades vizinhas (andar superior, inferior e laterais) limitam-se ao ruído operacional descrito na Seção 8, sendo mitigados pela adoção do horário permitido e pela execução com ferramental adequado."),

  // ========== 11. PROCEDIMENTOS EXECUTIVOS ==========
  h1("11. Procedimentos Executivos"),
  p("A execução dos serviços observará as boas práticas de engenharia e as seguintes diretrizes operacionais:"),
  bullet("As demolições serão realizadas com ferramentas manuais leves, evitando impactos excessivos sobre estruturas e vedações da edificação."),
  bullet("Será adotado controle contínuo de ruído, poeira e vibração durante toda a execução dos serviços, com respeito aos horários previstos no regulamento interno do condomínio."),
  bullet("As rotas de circulação, elevadores de serviço e áreas comuns utilizadas para acesso à obra serão devidamente protegidas com material de proteção temporária (lona, papelão ondulado, mantas) contra danos."),
  bullet("A autorização para circulação de insumos e funcionários no condomínio observará os horários e procedimentos determinados pela administração, conforme item 5.1, alínea “c”, da norma."),
  bullet("Ao final de cada jornada, o ambiente de obra será isolado e as áreas comuns utilizadas serão higienizadas pela empresa executora."),

  // ========== 12. RESÍDUOS ==========
  h1("12. Gestão de Resíduos e Armazenamento de Insumos"),
  p("Em atendimento aos itens 5.1, alíneas “l” e “m”, da NBR 16.280:2024 e à Resolução CONAMA nº 307/2002 e alterações:"),
  subh("12.1 Armazenamento de insumos"),
  bullet("Os insumos (argamassa, rejunte, tintas, revestimentos, ferramentas) serão armazenados exclusivamente no interior da unidade, em local pré-definido com a proprietária, não ocupando áreas comuns do condomínio."),
  bullet("Produtos em pó serão mantidos em sacos fechados e em local seco, afastados de instalações elétricas."),
  subh("12.2 Gestão de resíduos"),
  bullet("Todo o entulho gerado será acondicionado em big bags ou recipientes adequados, identificados, dispostos em local previamente acordado com a administração do condomínio (tipicamente próximos à saída de serviço, sem interferir na circulação)."),
  bullet("O transporte e o descarte ocorrerão por meio de empresa transportadora devidamente licenciada, com destinação final em área regularizada perante os órgãos ambientais competentes."),
  bullet("Serão mantidos, à disposição do responsável legal, os Certificados de Destinação Final (CDF) dos resíduos gerados."),
  bullet("As áreas comuns serão mantidas limpas e desobstruídas ao final de cada jornada."),

  // ========== 13. CONTROLE DE ETAPAS E ALTERAÇÃO DE ESCOPO ==========
  h1("13. Controle de Terminalidade e Alteração de Escopo"),
  p("Em atendimento aos itens 5.2.3 e 5.2.4 da NBR 16.280:2024:"),
  bullet("Durante a execução, serão implementados controles de terminalidade que validem o recebimento de cada etapa da obra, em conformidade com os requisitos legais e com as especificações deste memorial."),
  bullet("Caso, ao longo da execução, seja constatada a necessidade de alteração do escopo originalmente aprovado, a obra será imediatamente suspensa e o acesso de materiais e funcionários será proibido."),
  bullet("Toda a documentação técnica será submetida à nova análise pelo responsável técnico signatário, com emissão de complemento ao presente memorial e comunicado formal ao proprietário e ao responsável legal da edificação. Somente após essa reaprovação a obra poderá ser retomada."),
  bullet("Havendo risco iminente à segurança ou ao uso da edificação, serão adotadas de imediato as ações técnicas, legais e emergenciais cabíveis, e as medidas de recuperação e restauro das condições de segurança serão acionadas."),

  // ========== 14. DESEMPENHO E MANUTENÇÃO ==========
  h1("14. Desempenho e Continuidade da Manutenção"),
  p("Em atendimento ao item 4, alínea “h”, da NBR 16.280:2024, os serviços descritos serão executados de modo a preservar integralmente:"),
  bullet("A estabilidade estrutural da edificação, em conformidade com a ABNT NBR 6118."),
  bullet("O desempenho dos sistemas prediais existentes — elétrico, hidráulico, de esgoto, de impermeabilização e de vedação — conforme os requisitos da ABNT NBR 15575."),
  bullet("A continuidade dos planos e rotinas de manutenção preventiva e corretiva da edificação, conforme a ABNT NBR 5674, não criando impedimentos ou obstruções às atividades periódicas de inspeção e conservação."),
  bullet("A habitabilidade e a salubridade dos ambientes, ao término das intervenções."),

  // ========== 15. MANUAL E GARANTIAS (NBR 14037 + 17170) ==========
  h1("15. Atualização do Manual de Uso, Operação e Manutenção"),
  p("Em cumprimento expresso ao item 5.1, alínea “n”, da NBR 16.280:2024, a proprietária declara ciência e compromete-se a:"),
  bullet("Atualizar o Manual de Uso, Operação e Manutenção da unidade, nos termos da ABNT NBR 14037, incorporando as instruções de uso e manutenção das partes da unidade afetadas pela reforma. As instruções serão fornecidas pela empresa executora e pelo responsável técnico ao término da obra."),
  bullet("Caso a unidade ainda não disponha de manual — por se tratar de edificação anterior à obrigatoriedade da NBR 14037 — as intervenções objeto desta reforma serão acompanhadas da elaboração do respectivo manual, conforme a norma."),
  bullet("Observar as possíveis implicações da reforma sobre a gestão da manutenção, sobre as incumbências referentes às garantias e sobre as próprias condições e prazos de garantia, nos termos da ABNT NBR 17170, devendo as novas condições e prazos pactuados serem formalmente incorporados ao manual."),
  p("O responsável técnico alerta a proprietária, desde já, de que intervenções em sistemas originalmente entregues pela incorporadora podem, nos termos da NBR 17170, afetar os prazos e as condições das garantias remanescentes. Todas as intervenções aqui descritas foram planejadas para minimizar essa implicação."),

  // ========== 16. TERMO DE ENCERRAMENTO ==========
  h1("16. Termo de Encerramento da Obra"),
  p("Em atendimento ao item 6.1.3, alínea “a”, da NBR 16.280:2024, ao término da execução o responsável técnico signatário emitirá o respectivo Termo de Encerramento da Obra, entregando-o ao responsável legal da edificação acompanhado de:"),
  bullet("Declaração de que a obra foi executada em conformidade com o plano aprovado e com o presente memorial descritivo."),
  bullet("Manual de uso, operação e manutenção atualizado, nos termos da Seção 15 deste memorial."),
  bullet("Certificados de destinação final (CDF) dos resíduos gerados."),
  bullet("Registro fotográfico do estado final das áreas intervenidas."),
  p("A partir do recebimento do Termo de Encerramento, cessam as autorizações para circulação de insumos e prestadores de serviço vinculados à obra nas dependências do condomínio."),

  // ========== 17. LIMITAÇÕES ==========
  h1("17. Limitações da Intervenção"),
  p("Para pleno enquadramento na categoria de reforma sem impacto no sistema da edificação, a obra NÃO contempla:"),
  ...LIMITACOES.map((l) => bullet(l)),

  // ========== 18. CONCLUSÃO ==========
  h1("18. Conclusão"),
  p("Diante de todo o exposto, a reforma descrita neste memorial caracteriza-se como intervenção em acabamentos e itens superficiais, sem impacto sobre elementos estruturais, prumadas coletivas ou áreas comuns, atendendo plenamente aos critérios estabelecidos pela ABNT NBR 16.280:2024."),
  p("Encontra-se, portanto, apta à execução mediante:"),
  bullet("Emissão da Anotação de Responsabilidade Técnica (ART) pelo profissional signatário junto ao CREA-SP."),
  bullet("Encaminhamento formal deste memorial ao responsável legal da edificação (síndico/administração), com a documentação complementar exigida pelo regimento interno, nos termos do item 6.2.1 da norma."),
  bullet("Análise e aprovação formal pela administração do condomínio, nos termos da norma e da convenção condominial."),
  bullet("Cumprimento integral dos procedimentos, controles e compromissos aqui descritos, com especial atenção à emissão do Termo de Encerramento da Obra e à atualização do Manual de Uso, Operação e Manutenção, ao término dos serviços."),

  new Paragraph({ spacing: { after: 200 }, children: [new TextRun({ text: "" })] }),
  blocoAssinatura,
];

// ============================================================================
// DOCUMENTO
// ============================================================================
const doc = new Document({
  creator: "Veríssimo Gestão Técnica Predial",
  title: "Memorial Descritivo de Reforma - NBR 16.280:2024",
  description: "Memorial Descritivo de Reforma em Unidade Autônoma - ABNT NBR 16.280:2024",
  styles: {
    default: { document: { run: { font: "Georgia", size: 22, color: DARK_TEXT } } },
    paragraphStyles: [
      {
        id: "Heading1",
        name: "Heading 1",
        basedOn: "Normal",
        next: "Normal",
        quickFormat: true,
        run: { size: 26, bold: true, font: "Georgia", color: NAVY },
        paragraph: { spacing: { before: 360, after: 160 }, outlineLevel: 0 },
      },
    ],
  },
  numbering: {
    config: [
      {
        reference: "bullets",
        levels: [
          {
            level: 0,
            format: LevelFormat.BULLET,
            text: "▪",
            alignment: AlignmentType.LEFT,
            style: {
              paragraph: { indent: { left: 540, hanging: 280 } },
              run: { color: GOLD, font: "Georgia" },
            },
          },
        ],
      },
    ],
  },
  sections: [
    {
      properties: {
        page: {
          size: { width: 11906, height: 16838 }, // A4
          margin: { top: 1700, right: 1440, bottom: 1440, left: 1440, header: 560, footer: 400 },
        },
      },
      headers: { default: header },
      footers: { default: footer },
      children: conteudo,
    },
  ],
});

Packer.toBuffer(doc).then((buf) => {
  const out = DADOS.nome_arquivo;
  fs.writeFileSync(out, buf);
  console.log("OK:", out);
});
