# Tabela A.1 — Classificação da responsabilidade (NBR 16.280:2024, Anexo A)

A Tabela A.1 (informativa) orienta a classificação entre **empresa capacitada** e **empresa especializada**. Use esta referência na **Seção 2 — Caracterização e classificação da reforma** do memorial.

## Definições (§3.2 e §3.3)

- **Empresa capacitada**: organização ou pessoa que recebeu capacitação, orientação e responsabilidade de profissional habilitado e trabalha sob essa responsabilidade (conforme NBR 5674).
- **Empresa especializada**: organização ou profissional liberal que exerça função na qual são exigidas qualificação e competência técnica específicas (conforme NBR 5674).

## Tabela de decisão

| Sistema | Atividade | Responsável |
|---------|-----------|-------------|
| **Equipamentos industrializados** | Instalação com características diferentes das originais | Especializada |
| | Reforma para continuidade de uso | Capacitada |
| **Hidrossanitário** | Alteração do sistema / demanda diferente | Especializada |
| | Dispositivos com características originais | Capacitada |
| **Prevenção e combate a incêndio** | Alteração do sistema / demanda diferente | Especializada |
| | Dispositivos com características originais | Capacitada |
| **Instalações elétricas** | Alteração do sistema / demanda diferente | Especializada |
| | Dispositivos com características originais (ex.: troca de espelhos, interruptores) | Capacitada |
| **Instalações de gás** | Alteração do sistema / demanda diferente | Especializada |
| | Dispositivos com características originais | Capacitada |
| **Dados e comunicação** | Alteração do sistema | Especializada |
| | Dispositivos com características originais | Capacitada |
| **Automação** | Alteração do sistema | Especializada |
| | Dispositivos com características originais | Capacitada |
| **Ar-condicionado, exaustão, ventilação** | Alteração do sistema | Especializada |
| | Dispositivos com características originais | Capacitada |
| **Novos componentes à edificação** | Instalação de componente não previsto no projeto original; alteração de áreas | Especializada |
| **Revestimentos** | **Troca SEM martelete / ferramenta de alto impacto** | **Capacitada** |
| | **Troca COM martelete / ferramenta de alto impacto** | **Especializada** |
| **Impermeabilização** | Qualquer substituição ou interferência na integridade/proteção mecânica | Especializada |
| **Vedação** | Interferência na integridade, alteração de disposição, retirada ou inserção de elementos | Especializada |
| **Esquadrias e fachada-cortina** | Alteração / especificação diferente da original | Especializada |
| | Substituição com características originais | Capacitada |
| **Estrutura** | Qualquer intervenção (furos, abertura, reforço, restauro, alteração de carga/seção/área, acréscimo ou remoção de paredes, alteração de função/uso) | **Especializada (sempre)** |

## Regra adicional

A norma lembra que:
- **Empresas especializadas apresentam documentos de responsabilidade técnica (ART/RRT/TRT)** sobre os trabalhos executados, classificando as atividades e informando o profissional responsável.
- **Trabalhos em altura** possuem regulamentação específica (NR-35).

## Decisão para memoriais padrão Veríssimo

### Reforma "leve" típica (troca de piso, pintura, ajustes de espelhos)
- Se a **troca de piso usa martelete** → **Especializada** (automaticamente arrasta a classificação)
- Se a troca de piso é feita por **remoção manual** (sem alto impacto) → pode ser **Capacitada**, desde que não haja outro item especializado

### Presença de QUALQUER um dos abaixo → **Especializada**
- Martelete / demolidor
- Impermeabilização
- Alteração de prumada ou de circuito
- Alteração de parede de vedação (mesmo não estrutural)
- Nova tomada / novo ponto que altere carga instalada
- Alteração de esquadria ou fachada-cortina

### Regra de segurança
Na dúvida, **declare a obra como Especializada**. É mais defensável e exige ART, que é o documento técnico que o memorial já instrui a emitir.

## Como citar no memorial

Na **Seção 2 — Caracterização e classificação**, incluir:

> "Conforme critério estabelecido pelo Anexo A (Tabela A.1) da ABNT NBR 16.280:2024, a presente reforma classifica-se como intervenção executável por **[empresa capacitada | empresa especializada]**, considerando [justificativa: ex.: a ausência de ferramentas de alto impacto e a manutenção das características originais dos dispositivos intervenidos; OU a presença de intervenção com martelete para remoção de revestimento cerâmico]."
