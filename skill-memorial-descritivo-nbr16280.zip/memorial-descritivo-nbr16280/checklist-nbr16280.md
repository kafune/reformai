# Checklist NBR 16.280:2024 — Validação do memorial

Use este checklist ANTES de entregar o DOCX. Todos os itens marcados como **(OBRIG.)** são obrigatórios pela norma — a ausência caracteriza descumprimento.

## §5.1 — Requisitos gerais do plano (14 itens)

- [ ] **5.1.a (OBRIG.)** — Declaração de atendimento às legislações vigentes e normas técnicas → *Seção 6*
- [ ] **5.1.b (OBRIG.)** — Meios que garantam a segurança da edificação e dos usuários, durante e após a obra → *Seção 7*
- [ ] **5.1.c (OBRIG.)** — Autorização para circulação de insumos e funcionários nos horários permitidos → *Seção 11 (procedimentos)*
- [ ] **5.1.d (OBRIG.)** — Apresentação do memorial descritivo (o próprio documento cumpre este item)
- [ ] **5.1.e (OBRIG.)** — Escopo dos serviços → *Seção 3*
- [ ] **5.1.f (OBRIG.)** — Identificação de atividades geradoras de ruído + níveis de pressão sonora máxima previstos → *Seção 8*
- [ ] **5.1.g (OBRIG.)** — Identificação de uso de materiais tóxicos, combustíveis e inflamáveis → *Seção 9*
- [ ] **5.1.h (OBRIG.)** — Localização e implicações no entorno → *Seção 10*
- [ ] **5.1.i (OBRIG.)** — Cronograma → *Seção 4*
- [ ] **5.1.j (OBRIG.)** — Dados das empresas, profissionais e funcionários → *Seção 5*
- [ ] **5.1.k (OBRIG.)** — Responsabilidade técnica documentada (ART) → *Seção 5 + bloco de assinatura*
- [ ] **5.1.l (OBRIG.)** — Planejamento de descarte de resíduos → *Seção 12*
- [ ] **5.1.m (OBRIG.)** — Local de armazenamento de insumos e resíduos → *Seção 12*
- [ ] **5.1.n (OBRIG.)** — **Obrigatoriedade de atualização dos manuais conforme NBR 14037 + alerta sobre garantias conforme NBR 17170** → *Seção 15*

## §5.2 — Áreas privativas

- [ ] **5.2.1 (OBRIG.)** — Declaração de que os sistemas de segurança da edificação permanecerão em funcionamento → *Seção 7*
- [ ] **5.2.2 (OBRIG.)** — Declaração de não-obstrução das saídas de emergência (referência NBR 9077) → *Seção 7*
- [ ] **5.2.3 (OBRIG.)** — Previsão de controles de terminalidade e recebimento de etapas → *Seção 13*
- [ ] **5.2.4 (OBRIG.)** — Procedimento em caso de alteração de escopo (suspensão, nova análise, comunicado formal) → *Seção 13*

## §4 + §6 — Diretrizes e incumbências

- [ ] **§4.h** — Garantia de que a reforma não prejudica a continuidade da manutenção (NBR 5674) → *Seção 14*
- [ ] **§6.1.3.a (OBRIG.)** — Compromisso de entrega do Termo de Encerramento da Obra ao responsável legal + manual atualizado (NBR 14037) → *Seção 16*
- [ ] **§6.2.1 (OBRIG.)** — Memorial encaminhado ao responsável legal ANTES do início da obra → *menção na Seção 1 (objetivo)*

## Padrão visual Veríssimo

- [ ] Cabeçalho de página com logotipo navy + gold
- [ ] Régua dourada abaixo do cabeçalho
- [ ] Rodapé com CNPJ 60.353.313/0001-55, endereço e paginação
- [ ] Títulos em navy (#0B1F3A) com régua dourada (#C8A24B) inferior
- [ ] Bullets `▪` em dourado
- [ ] Fonte Georgia para corpo
- [ ] Selo da capa dizendo **"Conforme ABNT NBR 16.280:2024"** (NUNCA 2015)

## Dados obrigatórios

- [ ] Nome completo do RT: Erisvaldo Veríssimo da Silva
- [ ] Título: Engenheiro Civil
- [ ] CREA-SP 5070239349
- [ ] CNPJ da empresa: 60.353.313/0001-55
- [ ] Endereço: Av. Salgado Filho, 2150 – Sala 303C – Guarulhos/SP
- [ ] Data de emissão correta (dia de hoje)

## Validação técnica do DOCX

- [ ] `python3 /mnt/skills/public/docx/scripts/office/validate.py <arquivo>` retorna "All validations PASSED"
- [ ] Preview em PDF da página 1 mostra capa navy com selo 2024
- [ ] Última página contém bloco de assinatura centralizado

**Se qualquer item OBRIG. estiver em branco, o memorial NÃO pode ser entregue — volte ao gerar.js e corrija.**
